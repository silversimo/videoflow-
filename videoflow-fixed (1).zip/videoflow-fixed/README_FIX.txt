VideoFlow v7.4 — FIXED
========================

المشاكل التي تم إصلاحها:
--------------------------
1. MainActivity.java كان فارغاً (محتواه AndroidManifest بالخطأ)
   → تم بناؤه من صفر مع كامل محرك التحميل

2. extractAndDownload() لم يكن يفعل شيئاً
   → الآن يستدعي YouTube API (yt1s.io) + RapidAPI للمنصات الأخرى
   → ثم DownloadManager الحقيقي

3. شريط التقدم معلق للأبد
   → Java يستدعي window._vfProg() و window.onDownloadComplete() بشكل صحيح

4. pasteToInput() لم تكن محددة في Java
   → مضافة مع ClipboardManager

5. AdMob APPLICATION_ID ناقص
   → مضاف في AndroidManifest.xml

خطوة مطلوبة:
--------------
في MainActivity.java السطر ~35:
  RAPID_API_KEY = "YOUR_RAPIDAPI_KEY_HERE"
استبدل بمفتاح مجاني من:
  https://rapidapi.com → ابحث عن "social-media-video-downloader"
  (يدعم TikTok, Instagram, Facebook, Twitter...)
  YouTube يعمل بدون مفتاح عبر yt1s.io

Build:
------
  cd android
  ./gradlew assembleRelease
