package com.downloader.app;

import android.Manifest;
import android.app.DownloadManager;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private Handler mainHandler;
    private ExecutorService executor;
    private static final int PERM_REQUEST = 100;

    // ── RapidAPI key ─────────────────────────────────────────────────────
    // احصل على مفتاح مجاني من: https://rapidapi.com/search/social-media-video-downloader
    private static final String RAPID_API_KEY  = "YOUR_RAPIDAPI_KEY_HERE";
    private static final String RAPID_API_HOST = "social-media-video-downloader.p.rapidapi.com";
    private static final String RAPID_API_URL  = "https://social-media-video-downloader.p.rapidapi.com/smvd/get/all";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Layout بسيط: WebView يملأ الشاشة كاملة
        webView = new WebView(this);
        setContentView(webView);

        mainHandler = new Handler(Looper.getMainLooper());
        executor    = Executors.newFixedThreadPool(3);

        // تهيئة AdMob
        MobileAds.initialize(this, status -> {});

        setupWebView();
        requestPermissions();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  إعداد WebView
    // ══════════════════════════════════════════════════════════════════════
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest req) {
                return false; // كل الروابط تفتح داخل WebView
            }
        });

        // الجسر بين JavaScript وJava
        webView.addJavascriptInterface(new Bridge(), "Android");

        // تحميل الواجهة
        webView.loadUrl("file:///android_asset/public/index.html");
    }

    // ══════════════════════════════════════════════════════════════════════
    //  جسر JavaScript ↔ Java
    // ══════════════════════════════════════════════════════════════════════
    private class Bridge {

        /** يُستدعى من JS عند الضغط على زر التحميل بعد اختيار الجودة */
        @JavascriptInterface
        public void extractAndDownload(String videoUrl, String quality) {
            if (videoUrl == null || videoUrl.trim().isEmpty()) {
                showToast("الرجاء إدخال رابط صحيح");
                return;
            }
            updateProgress(15, "جاري استخراج الرابط…", "الاتصال بالخدمة");
            executor.execute(() -> resolveAndDownload(videoUrl.trim(), quality));
        }

        /** لصق النص من الحافظة في حقل الإدخال */
        @JavascriptInterface
        public void pasteToInput() {
            mainHandler.post(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null
                        && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence text = cm.getPrimaryClip().getItemAt(0).getText();
                    if (text != null && text.length() > 0) {
                        String safe = text.toString().replace("'", "\\'").replace("\n", "");
                        webView.evaluateJavascript(
                            "document.getElementById('urlInput').value='" + safe + "';", null);
                    }
                }
            });
        }

        /** فتح منصة اجتماعية داخل WebView */
        @JavascriptInterface
        public void openInAppWithDownloadBar(String url, String platform) {
            mainHandler.post(() -> webView.loadUrl(url));
        }

        /** تشغيل فيديو محفوظ */
        @JavascriptInterface
        public void openVideo(String path) {
            mainHandler.post(() -> {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                File f = new File(path);
                String mime = path.endsWith(".mp3") ? "audio/mpeg" : "video/mp4";
                intent.setDataAndType(Uri.fromFile(f), mime);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, "افتح بـ…"));
            });
        }

        /** إظهار Toast */
        @JavascriptInterface
        public void showToast(String msg) {
            mainHandler.post(() ->
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  محرك التحميل
    // ══════════════════════════════════════════════════════════════════════
    private void resolveAndDownload(String videoUrl, String quality) {
        try {
            String directUrl = resolveUrl(videoUrl, quality);

            if (directUrl == null || directUrl.isEmpty()) {
                // للروابط المباشرة .mp4/.mp3 نحمّل مباشرة
                if (videoUrl.contains(".mp4") || videoUrl.contains(".mp3")) {
                    directUrl = videoUrl;
                } else {
                    notifyError("تعذّر استخراج رابط التحميل. جرّب رابطاً آخر.");
                    return;
                }
            }

            updateProgress(55, "جاري التحميل…", "بدء النقل");
            String filename = buildFilename(videoUrl, quality);
            enqueueDownload(directUrl, filename);

        } catch (Exception e) {
            notifyError("خطأ: " + e.getMessage());
        }
    }

    /** استخراج الرابط المباشر عبر RapidAPI أو YouTube fallback */
    private String resolveUrl(String videoUrl, String quality) throws Exception {
        // YouTube بدون مفتاح API
        if (videoUrl.contains("youtube.com") || videoUrl.contains("youtu.be")) {
            return resolveYoutube(videoUrl, quality);
        }

        // باقي المنصات عبر RapidAPI
        if (RAPID_API_KEY.equals("YOUR_RAPIDAPI_KEY_HERE")) return null;

        URL url = new URL(RAPID_API_URL + "?url=" + Uri.encode(videoUrl));
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("X-RapidAPI-Key",  RAPID_API_KEY);
        conn.setRequestProperty("X-RapidAPI-Host", RAPID_API_HOST);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);

        if (conn.getResponseCode() != 200) return null;

        StringBuilder sb = readResponse(conn);
        JSONObject root = new JSONObject(sb.toString());
        if (!root.optBoolean("success", false)) return null;

        JSONArray links = root.optJSONArray("links");
        if (links == null || links.length() == 0) return null;

        String best = null;
        for (int i = 0; i < links.length(); i++) {
            JSONObject item = links.getJSONObject(i);
            String q   = item.optString("quality", "");
            String lnk = item.optString("link", "");
            if (quality.equals("mp3") && (q.contains("mp3") || q.contains("audio"))) return lnk;
            if (q.contains(quality.replace("p", ""))) return lnk;
            if (best == null) best = lnk;
        }
        return best;
    }

    /** YouTube via yt1s.io — مجاني بدون مفتاح */
    private String resolveYoutube(String videoUrl, String quality) {
        try {
            String vid = extractYoutubeId(videoUrl);
            if (vid == null) return null;

            // خطوة 1: تحليل
            URL url1 = new URL("https://yt1s.io/api/ajaxSearch/index");
            HttpURLConnection c1 = (HttpURLConnection) url1.openConnection();
            c1.setRequestMethod("POST");
            c1.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            c1.setDoOutput(true);
            c1.setConnectTimeout(15000);
            c1.setReadTimeout(15000);
            String vt = quality.equals("mp3") ? "mp3" : "mp4";
            c1.getOutputStream().write(("q=" + Uri.encode(videoUrl) + "&vt=" + vt).getBytes());
            if (c1.getResponseCode() != 200) return null;

            JSONObject r1  = new JSONObject(readResponse(c1).toString());
            String     kId = r1.optString("kc", "");
            if (kId.isEmpty()) return null;

            // خطوة 2: تحويل
            URL url2 = new URL("https://yt1s.io/api/ajaxConvert/convert");
            HttpURLConnection c2 = (HttpURLConnection) url2.openConnection();
            c2.setRequestMethod("POST");
            c2.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            c2.setDoOutput(true);
            c2.setConnectTimeout(20000);
            c2.setReadTimeout(20000);
            c2.getOutputStream().write(("vid=" + vid + "&k=" + Uri.encode(kId)).getBytes());
            if (c2.getResponseCode() != 200) return null;

            JSONObject r2 = new JSONObject(readResponse(c2).toString());
            return r2.optString("dlink", null);

        } catch (Exception e) {
            return null;
        }
    }

    /** استخراج معرف YouTube من الرابط */
    private String extractYoutubeId(String url) {
        if (url.contains("youtu.be/")) return url.split("youtu.be/")[1].split("[?&#]")[0];
        if (url.contains("v="))        return url.split("v=")[1].split("[?&#]")[0];
        return null;
    }

    /** تحميل الملف عبر DownloadManager */
    private void enqueueDownload(String directUrl, String filename) {
        File dir = new File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "VideoFlow");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();

        String mime = filename.endsWith(".mp3") ? "audio/mpeg" : "video/mp4";

        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(directUrl));
        req.setTitle(filename);
        req.setDescription("VideoFlow");
        req.setMimeType(mime);
        req.setNotificationVisibility(
            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
        req.setDestinationInExternalPublicDir(
            Environment.DIRECTORY_DOWNLOADS + "/VideoFlow", filename);
        req.allowScanningByMediaScanner();

        DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        if (dm == null) { notifyError("DownloadManager غير متاح"); return; }

        long dlId = dm.enqueue(req);
        pollProgress(dm, dlId, filename,
            dir.getAbsolutePath() + "/" + filename);
    }

    /** مراقبة تقدم التحميل وإخبار JS */
    private void pollProgress(DownloadManager dm, long id, String name, String path) {
        executor.execute(() -> {
            int prev = -1;
            while (true) {
                try { Thread.sleep(800); } catch (InterruptedException ignored) { break; }

                DownloadManager.Query q = new DownloadManager.Query();
                q.setFilterById(id);
                Cursor c = dm.query(q);
                if (c == null) break;
                if (!c.moveToFirst()) { c.close(); break; }

                int    status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                long   done   = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                long   total  = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_IN_BYTES));
                c.close();

                if (status == DownloadManager.STATUS_SUCCESSFUL) {
                    updateProgress(100, "✅ تم التحميل!", "محفوظ في Download/VideoFlow");
                    notifyComplete(path, name, true);
                    break;
                } else if (status == DownloadManager.STATUS_FAILED) {
                    notifyError("فشل التحميل. تحقق من الاتصال.");
                    break;
                } else if (total > 0) {
                    int pct = (int) (done * 80 / total) + 20;
                    if (pct != prev) {
                        prev = pct;
                        updateProgress(pct,
                            "جاري التحميل " + pct + "%",
                            (done / 1024) + " KB / " + (total / 1024) + " KB");
                    }
                }
            }
        });
    }

    // ══════════════════════════════════════════════════════════════════════
    //  استدعاء دوال JavaScript
    // ══════════════════════════════════════════════════════════════════════
    private void updateProgress(int pct, String title, String sub) {
        runJs("window._vfProg&&window._vfProg(" + pct + ",'" + esc(title) + "','" + esc(sub) + "')");
    }

    private void notifyComplete(String path, String name, boolean ok) {
        runJs("window.onDownloadComplete&&window.onDownloadComplete('" +
              esc(path) + "','" + esc(name) + "'," + ok + ")");
    }

    private void notifyError(String msg) {
        mainHandler.post(() ->
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
        runJs("var b=document.getElementById('progBox');if(b)b.style.display='none';");
    }

    private void runJs(String js) {
        mainHandler.post(() -> webView.evaluateJavascript(js, null));
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
    }

    // ══════════════════════════════════════════════════════════════════════
    //  دوال مساعدة
    // ══════════════════════════════════════════════════════════════════════
    private String buildFilename(String url, String quality) {
        String stamp = String.valueOf(System.currentTimeMillis());
        String ext   = quality.equals("mp3") ? ".mp3" : ".mp4";
        if (url.contains("youtube") || url.contains("youtu.be")) return "YT_" + stamp + ext;
        if (url.contains("tiktok"))    return "TT_" + stamp + ext;
        if (url.contains("instagram")) return "IG_" + stamp + ext;
        if (url.contains("facebook") || url.contains("fb.watch")) return "FB_" + stamp + ext;
        if (url.contains("twitter") || url.contains("x.com"))     return "TW_" + stamp + ext;
        return "VF_" + stamp + ext;
    }

    private StringBuilder readResponse(HttpURLConnection conn) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (InputStream is = conn.getInputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) != -1) sb.append(new String(buf, 0, n));
        }
        return sb;
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) return;
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                }, PERM_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms,
                                           @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == PERM_REQUEST) webView.reload();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executor != null) executor.shutdownNow();
    }
}
